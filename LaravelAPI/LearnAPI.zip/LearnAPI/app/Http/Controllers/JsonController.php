<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\App;
class JsonController extends Controller
{
    public static function sendJson(Request $request)
    {




        $data = [
            'ip' => $request->getClientIp(),
            'host' => $request->getHost(),
            'lang' => $request->getLocale(),
            "port" => $request->getPort(),
            "encoding" => $request->getEncodings(),
            "OS" => $request->header("sec-ch-ua-platform"),



        ];
        return response()->json($data);
    }
}
