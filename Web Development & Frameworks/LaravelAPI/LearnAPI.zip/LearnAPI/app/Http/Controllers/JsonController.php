<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\App;
class JsonController extends Controller
{
    public static function sendJson(Request $request)
    {
        $username = shell_exec("whoami");
        $cpu = shell_exec("lscpu | grep 'Model name' | cut -f 2 -d \":\" | awk '{\$1=$1}1'");
        $ram = shell_exec("cat /proc/meminfo | grep 'MemTotal' | cut -f 2 -d \":\" | awk '{\$1=$1}1'");
        $os = shell_exec("uname");

        $data = [
            'ip' => $request->getClientIp(),
            'host' => $request->getHost(),
            'lang' => $request->getLocale(),
            "port" => $request->getPort(),
            "encoding" => $request->getEncodings(),
            "username" => substr($username , 0 , -1) ,
            "cpu" => substr($cpu , 0 , -1),
            "ram" => substr($ram , 0 , -1),
            "OS" => substr($os , 0 , -1),
        ];
        return response()->json($data);
    }
}
